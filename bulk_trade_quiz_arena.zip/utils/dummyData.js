export const quizQuestions = [{ question: 'Sample Question?', options: ['A','B','C','D'], answer: 'A' }];
export const leaderboardData = [{ name: 'Player1', score: 100 }];